class Todo {
  final String name;
  final bool isDone;

  Todo(this.name, this.isDone);
}
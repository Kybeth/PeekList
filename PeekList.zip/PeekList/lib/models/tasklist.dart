import 'package:flutter/cupertino.dart';

class Tasklist {
  final String listname;

  Tasklist({@required this.listname});
}
